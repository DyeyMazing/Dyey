# __learn basic csharp__

This is the repo for an introduction to C# lesson. Formal learning page is at [https://trashvin.github.io/learn-basic-csharp/](https://trashvin.github.io/learn-basic-csharp/).

For any corrections please create a pull request.