﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pos_library.interfaces;

namespace pos_library.classes.pos.desktops
{
    public class LinuxDesktopPOS  
    {
    }
}
