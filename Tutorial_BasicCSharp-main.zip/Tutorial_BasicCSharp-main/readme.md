# __Basic C# Tutorial__

This is the repo for an introduction to C# lesson. Formal learning page is at [https://trashvin.github.io/Tutorial_BasicCSharp/](https://trashvin.github.io/Tutorial_BasicCSharp/)

For any corrections please create a pull request.
